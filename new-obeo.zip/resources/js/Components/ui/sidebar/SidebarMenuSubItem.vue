<script setup lang="ts"></script>

<template>
  <li>
    <slot />
  </li>
</template>
