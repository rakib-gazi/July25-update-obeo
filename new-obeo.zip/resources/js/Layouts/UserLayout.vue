

<template>
    <div class="bg-gray-100">
        <slot />
    </div>
</template>

